﻿using System;
using System.Collections.Generic;

namespace Capgemini.GreatOutdoor.Helpers
{
    public enum UserType
    {
        Admin, SalesPerson, Retailer
    }
}



